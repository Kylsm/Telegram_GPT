
import os
import openai
from flask import Flask, request
import requests

app = Flask(__name__)

BOT_TOKEN = os.getenv("BOT_TOKEN")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
openai.api_key = OPENAI_API_KEY

TELEGRAM_API_URL = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"

def clean_and_explain_text(user_text):
    prompt = (
        "النص التالي يحتوي على أخطاء ناتجة من المسح الضوئي OCR مثل: كلمات متشابكة، "
        "أو معكوسة، أو غير مفهومة. الرجاء إعادة صياغة النص وجعله واضحًا وسليمًا لغويًا، "
        "مع الحفاظ على المعنى قدر الإمكان:

" + user_text
    )
    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "أنت مساعد لغوي ذكي، وظيفتك تصحيح وتنقيح النصوص العربية التي تحتوي على تشويش من OCR."},
                {"role": "user", "content": prompt}
            ]
        )
        return response['choices'][0]['message']['content']
    except Exception as e:
        return f"❌ حصل خطأ أثناء التواصل مع GPT: {str(e)}"

@app.route("/", methods=["POST"])
def webhook():
    data = request.get_json()
    if "message" in data and "text" in data["message"]:
        chat_id = data["message"]["chat"]["id"]
        user_text = data["message"]["text"]

        reply = clean_and_explain_text(user_text)

        payload = {
            "chat_id": chat_id,
            "text": reply
        }
        requests.post(TELEGRAM_API_URL, json=payload)
    return "ok", 200

@app.route("/")
def home():
    return "Bot is running!", 200
